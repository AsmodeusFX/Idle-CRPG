from pathlib import Path
import csv,collections,hashlib
P=Path(__file__).parent
read=lambda p:list(csv.DictReader(open(P/p,encoding='utf-8-sig',newline='')))
a=read('C2A_393场地与楼层统一绑定索引_P.csv')
f=read('C2A_226层节拍与唯一生成消费者合同.csv')
c=read('C2A_31城堡与Boss实际内容门禁.csv')
m=read('C2A_38怪物身份工程绑定与行为门禁.csv')
r=read('C2A_31区域身份池与来源合同.csv')
e=read('C2B_28装备模板到生产品质ID逐项转换.csv')
l=read('C2B_31实际怪级装备与耗材候选掉率_单位统一.csv')
x=read('C2B_5卷轴4药剂真实行为与工程扩展合同.csv')
b=read('C2_C3_主线与可选内容预算纠偏_关键红项.csv')
assert len(a)==393 and len({q['ContentKey'] for q in a})==393
assert collections.Counter(q['NodeType'] for q in a)=={'DUNGEON':136,'DUNGEON_FLOOR':226,'CASTLE':31}
assert len(f)==226 and len(c)==31 and len(m)==38 and len(r)==31 and len(read('C2A_4处普通地牢局部BossArena清单.csv'))==4
assert len(e)==28 and len(l)==31 and len(x)==9
assert sum(int(q['OptionalDungeonStaticKills']) for q in b)==1291
assert sum(int(q['CorrectedMainlineStaticBudget']) for q in b)==11189
assert sum(int(q['S11OldAllContentBudget']) for q in b)==12480
assert set(q['ProductionQualityId_APPROVED'] for q in e)=={'common','uncommon','rare','legendary'}
assert len(set((q['DesignTemplateId']) for q in e))==28
assert {q['DesignId'] for q in x}=={'SC01','SC02','SC03','SC04','SC05','PO01','PO02','PO03','PO04'}
for p in read('SOURCE_MANIFEST_SHA256.csv'):
 path=P/p['InPackage'];assert hashlib.sha256(path.read_bytes()).hexdigest()==p['Sha256']
# P0 original archive, not inferred from S10/S09
import zipfile,io
with zipfile.ZipFile(P/'refs/P0-地图规则搭建.zip') as z:
    pois={};fls={}
    for n in z.namelist():
        if not n.endswith('.csv') or 'Chapter5/' in n or ('_POI_V' not in n and '_FLOOR_PLAN_V' not in n):continue
        rows=list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))
        for q in rows:
            key=str(int(q['ChapterId'][-2:]))+':'+q['PoiId']
            if '_POI_V' in n:pois[key]=q
            elif q['DifficultyId']=='NORMAL':fls[(key,int(q['FloorIndex']))]=q
assert len(pois)==167 and len(fls)==314
for q in a:
    if q['NodeType']=='DUNGEON_FLOOR':
        assert (q['ParentDungeonKey'],int(q['FloorIndex'])) in fls, q['ContentKey']
    else:
        assert q['ContentKey'] in pois and pois[q['ContentKey']]['Type']==('Dungeon' if q['NodeType']=='DUNGEON' else 'Castle'),q['ContentKey']
print('P0_DIRECT_ORIGINAL_PASS poi=167 all_normal_floors=314 content_keys=393')
print('C2_STATIC_PASS keys=393 floors=226 castles=31 monsters=38 regions=31 equip=28 consumables=9 optional_kills=1291 mainline_old_static=11189')
